using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        public static void Main(string[] args)
        {
            Story.intro();

            var player = new Story(" ");     //instantiated object player from the Player class

            Story.theBeginning();       //invokes the first story method to begin the game
            Story.setName(player);    //calls the getName method to get player's name

            if(String.Compare(player.PlayerName, "skip", true) != 0) //allows players to skip to randomized calls
            {
                Story.fireFighterIntro();
                Story.toTheTruck();

                var mva = new Calls(0, false, false, 0);
                Calls.genCall(mva);
                //To check RNG
                //Console.WriteLine(mva.RootCause + " " + mva.Victims + " " + mva.Fire + " " + mva.Onlookers);

                mva.exeCallmva(mva);

                Story.backToTheStation();

                var struc = new Calls(0, false, false, 0);
                Calls.genCall(struc);
                struc.exeCallStruc(struc);

                Story.laterThatNight();

                var med = new Calls(0, false, false, 0);
                Calls.genCall(med);
                med.exeCallsMed(med);

                Story.endOfShift();
            }
            else                                                         //when the player chooses to skip the story
            {
                Console.WriteLine("\nYou have chosen to skip the story...");
            }

            Random rnd = new Random();
            var rand = new Calls(0, false, false, 0);

            while (Console.ReadKey().Key != ConsoleKey.Escape) //allows them to exit after each call
            {
                Story.randomCallIntro();

                Calls.genCall(rand);

                int i = rnd.Next(1, 4);

                switch(i)
                {
                    case 1:
                        rand.exeCallmva(rand);
                        break;
                    case 2:
                        rand.exeCallStruc(rand);
                        break;
                    case 3:
                        rand.exeCallsMed(rand);
                        break;
                    default:
                        break;
                }
                Story.randomCallFin();
            }
        }
    }
}
