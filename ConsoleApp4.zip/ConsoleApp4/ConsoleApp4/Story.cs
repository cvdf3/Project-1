﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Story
    {
        //properties
        public string PlayerName { get; set; }

        //constructors
        public Story(string name)
        {
            this.PlayerName = name;
        }

        //methods
        public static void intro()
        {
            Console.WriteLine("           ########################################################################" +
                "####################\n" +
                "           ##################################################################################" +
                "##########\n" +
                "           Hello, this is a small project I created to try and better familiarize myself with the\n" +
                "           concept of creating classes and objects in an Object Oriented Language.  It is small game\n" +
                "           that tries to convey some of the experience of being a firefighter, as I have been for the\n" +
                "           last six years.  As the adage goes \"write what you know\", so I tried to draw from\n" +
                "           experience for inspiration.\n" +
                "           ##################################################################################" +
                "##########\n" +
                "           ##################################################################################" +
                "##########\n");
        }

        private static bool palindrome(string x)
        {
            string revX = new string(x.Reverse().ToArray());

            return x == revX ? true : false;
        }
        public static string setName(Story player)     //method to obtain the player's name
        {
            string userInput = Console.ReadLine();      //prevents mutliple linebreaks within the console

            if(String.Compare(userInput, "Tom sucks", true) == 0 || String.Compare(userInput, "Tom suxs", true) == 0 )
            {
                Console.WriteLine("\nTom: Very funny, but for real though...\n");
                Console.ReadKey(true);
                return setName(player);  //recursive function to make the player choose a different name
            }
            else if(String.Compare(userInput, "Prosser", true) == 0) //compare to make case-insensitive
            {
                player.PlayerName = userInput;
                Console.WriteLine($"\nTom: {player.PlayerName}? Now that's a cool name!");
            }
            else if(String.Compare(userInput, "Tom", true) == 0)
            {
                player.PlayerName = userInput;
                Console.WriteLine($"\nTom: You're a {player.PlayerName} too? Glad to meet ya!\n");
            }
            else if(String.Compare(userInput, "skip", true) == 0)
            {
                player.PlayerName = userInput;
            }
            else if(palindrome(userInput))
            {
                player.PlayerName = userInput;
                Console.WriteLine($"\nTom: Cool name {player.PlayerName}, you can spell it the same forward " +
                    "and backward!");
            }
            else if (userInput.Contains("Butt") || userInput.Contains("butt"))
            {
                player.PlayerName = userInput;
                Console.WriteLine($"\nTom: {player.PlayerName} huh? Well, that's unfortunate...");
            }
            else
            {
                player.PlayerName = userInput;
                Console.WriteLine($"\nTom: Nice to meet ya {player.PlayerName}!");
            }
            Console.ReadKey(true);
            return player.PlayerName;
        }
            
        public static void theBeginning()
        {
            Console.WriteLine("Fresh from the academey, you arrive at the station you were " +
                "assigned, Station 2. You are greeted by a tall man with a\n" +
                "thick moustache, who swiftly thrusts a bear paw of a hand toward you and bellows\n\n");
            Console.ReadKey(true);
            Console.WriteLine("Tom: The name's Tom, what's your's probie?\n");
        }

        public static void fireFighterIntro()
        {
            Console.WriteLine("Well let me show ya around and introduce you to the guys.\n\n" +
                "You follow him down the hall of the station and hang a left leading to the kitchen.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Tom: Brandon, Mike! Get over here; the new-blood's arrived.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("You hear laughter coming from the room at the other end of the kitchen as two" +
                " stout firefighters come around the corner with snears on their faces.\n\n" +
                "The taller of the two starts:\n");
            Console.ReadKey(true);

            Console.WriteLine("Brandon: Whats yer na-\n");
            Console.ReadKey(true);

            Console.WriteLine("Before he can finish a deafening blare comes over the intercom speaker \n");
            Console.ReadKey(true);

            Console.WriteLine("Dispatcher: Attention Station 2, standby for a motor vehicle accident.\n");
            Console.ReadKey(true);

            Console.WriteLine("Mike: Welp, no time now we gotta go. Follow us newbie, you'll be in the back of" +
                " the truck with me.\n");
            Console.ReadKey(true);
        }

        public static void toTheTruck()
        {
            Console.WriteLine("You run after Mike to the truck, throw on your gear and hop in. Brandon" +
                " throws on the siren and your off.\n");
            Console.ReadKey(true);

            Console.WriteLine("Mike: Alright man, first day, first job. Let's see what ya got.\n");
            Console.ReadKey(true);
        }

        private static void pickTraining()  //used in the backToTheStation method
        {
            Console.WriteLine("  1. Bunker Drills\n  2. Hose pulls\n  3. Hydrant Connections\n\n");

            string userInput = Console.ReadLine();
            switch (userInput)
            {
                case "1":
                case "Bunker Drills":
                case "bunker drills":
                    Console.WriteLine("\nYou spend the rest of the morning practicing donning your gear, " +
                        "making sure you can get it all on in less than the\n" +
                        "required less than 60 seconds.\n\n");
                    Console.ReadKey(true);
                    break;
                case "2":
                case "Hose Pulls":
                case "hose pulls":
                    Console.WriteLine("\nBrandon pulls the truck out of the stall and you spend the rest of the " +
                        "day practicing pulling the handlines off. While they\n" +
                        "give you a hard time for your mistakes, Tom and Mike are\n" +
                        "quick to offer advice and you notice that you are better by the end.\n\n");
                    Console.ReadKey(true);
                    break;
                case "3":
                case "Hydrant Connections":
                case "hydrant connections":
                    Console.WriteLine("\nTom has the truck mount up and you spend the morning driving around the local " +
                        "area, practicing connecting the 5\" hose\n" +
                        "to a hydrant as fast as possible\n\n");
                    Console.ReadKey(true);
                    break;
                default:
                    Console.WriteLine("\nTom: You gotta do something, so pick...\n\n");
                    Console.ReadKey(true);
                    pickTraining();                 //recursive function to return to the list and pick a valid entry
                    break;
            }
        }

        public static void backToTheStation()
        {
            Console.WriteLine("\nBrandon: Good job out there, newbie.\n" +
                "We might make a real firefighter out of you yet.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("You arrive back at the station and Tom calls you over.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Tom: We need to do some refresher training, since you are fresh from the academy.\n" +
                "The choice of what you wanna start with is yours.\n\n");
            Console.ReadKey(true);

            pickTraining();

            Console.WriteLine("You make a quick lunch, hoping to relax a bit before you have to start working again.\n" +
                "Just as you sit down...\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Dispacter: Attention station 2, standby for structural fire.\n\n");
            Console.ReadKey(true);
            
            Console.WriteLine("You start running to the truck, Brandon yells as he hops in the truck\n\n" +
                "Brandon: The big one and on your first day, too? Get ready probie.\n\n");
            Console.ReadKey(true);

        }

        public static void laterThatNight()
        {
            Console.WriteLine("once you pull back into the station Mike inquires\n\n" + 
                "Mike: You bring dinner, we were gonna do a shift dinner, you're welcome to join, but you have to help " +
                "cook\n" +
                "You in?\n\n");

            string userInput = Console.ReadLine();
            if(String.Compare(userInput, "Yes", true) == 0 || String.Compare(userInput, "Y", true) == 0)
            {
                Console.WriteLine("\nMike: Good deal, I'll start getting stuff together, come to the kitchen " + 
                    "when your ready.\n\n");
                Console.ReadKey(true);

                Console.WriteLine("You get your stuff put up and join Mike in the kitchen. You can handle the " +
                    "pasta well enough and after an hour or\n" +
                    "so you all sit down for a healthy dinner.\n\n");
                Console.ReadKey(true);
            }
            else
            {
                Console.WriteLine("\nMike: Well, suit yourself, you gotta live with us, might as " +
                    "well get to know us...\n\n");
                Console.ReadKey(true);

                Console.WriteLine("You make a sandwhich by yourself after they clear out of the kitchen.\n" + 
                    "Not the best dinner you've had but it'll do.\n\n");
                Console.ReadKey(true);
            }

            Console.WriteLine("Sometime later you are getting ready for bed when you hear a famiar tone...\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Dispatcher: Standby medical for Station 2!\n\n");
            Console.ReadKey(true);

            Console.WriteLine("As you are running to the truck.." +
                "Tom: Starting to thing your a black cloud newbie!\n\n" + 
                "Mike: Well, at least he'll learn his job quick enough haha!\n\n");
            Console.ReadKey(true);

            Console.WriteLine("You jump into your seat, ready to go.");
            Console.ReadKey(true);

        }

        public static void endOfShift()
        {
            Console.WriteLine("You finally pull back into the station. Exhausted you climb into bed.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Luckily, you have a quiet night and wake up well rested, if not very sore.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("You pack your stuff and say goodbye to the guys as the oncoming crew arrives to " + 
                "relieve you all. You had a heck of\n" +
                "a first shift and you are excited for the next one in a couple days.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("##############################################\n" + 
                "           Thanks for playing!!\n\n" +
                "Press any button to continue your fire career!\n" +
                "##############################################");
        }

        public static void randomCallIntro()
        {
            Random rnd = new Random();

            bool day = rnd.Next(100) <= 50 ? true : false;

            string action = " ";
            string action2 = " ";
            string time = " ";

            int i = rnd.Next(1, 4);

            switch (i)
            {
                case 1:
                    if (day)
                    {
                        action = "you are washing the truck";
                    }
                    else
                    {
                        action = "doing the dishes";
                    }
                    action2 = "turn off the water";
                    break;
                case 2:
                    if (day)
                    {
                        action = "you are making some pasta for lunch";
                    }
                    else
                    {
                        action = "you are making dinner for the crew";
                    }
                    action2 = "turn off the stove";
                    break;
                case 3:
                    if (day)
                    {
                        action = "you are reclining in the day room";
                    }
                    else
                    {
                        action = "you are fast asleep after a long day of training";
                    }
                    action2 = "you jump up, a bit startled";
                    break;
                default:
                    break;

            }

            if (day)
            {
                time = "afternoon";
            }
            else
            {
                time = "evening";
            }

            Console.WriteLine("\n##############################################" +
                $"\nNext shift {action} during the {time}, when the tones go off.\n\n" + 
                $"You {action2}, throw your gear on, and jump in the truck ready to go.\n\n");
            Console.ReadKey(true); 
        }

        public static void randomCallFin()
        {
            Console.WriteLine("You pack up and head back to the station. The rest of the shift finishes up " + 
                "rather quietly.\n" +
                "##############################################");
            Console.ReadKey(true);
        }
    }
}
