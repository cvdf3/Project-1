﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Calls
    {
        //fields
        public int RootCause;
        public bool Victims;
        public bool Fire;
        public int Onlookers;

        //constructors
        public Calls(int rootCause, bool victims, bool fire, int onlookers)
        {
            this.RootCause = rootCause;
            this.Victims = false;
            this.Fire = false;
            this.Onlookers = onlookers;
        }

        //properties
        Random rnd = new Random();

        string crowd;

        //methods

        //generate the conditions for the call, separate method for each after
        public static void genCall(Calls x)
        {
            Random rnd = new Random();

            x.RootCause = rnd.Next(1, 5);
            x.Victims = rnd.Next(100) <= 60 ? true : false;
            x.Fire = rnd.Next(100) <= 60 ? true : false;
            x.Onlookers = rnd.Next(1, 26);

            //quantity of Onlookers
            if (x.Onlookers < 3)
            {
                x.crowd = "A couple of people have";
            }
            else if (x.Onlookers < 7)
            {
                x.crowd = $"A small cluster of {x.Onlookers} people have";
            }
            else if (x.Onlookers < 10)
            {
                x.crowd = $"A group of {x.Onlookers} people have";
            }
            else if (x.Onlookers < 15)
            {
                x.crowd = $"A considerable crowd of {x.Onlookers} people have";
            }
            else
            {
                x.crowd = $"A large sea of {x.Onlookers} people have";
            }
        }

        //
        //MVA
        //
        public void exeCallmva(Calls x)
        {
            bool entrapped = false;

            string obstacle = " ";
            string medical = " ";
            string fireCar = " ";
            string victimsCar;
            //string crowd;

            //determine RootCause
            switch (RootCause)
            {
                case 1:
                    obstacle = "that ran has crashed into a lightpole,\n" +
                            "leaving the both the front end of the car and lightpole bent from the impact";
                    break;
                case 2:
                    obstacle = "smashed into the side of a building.\n" +
                            "While the building itself looks to be fine, the vehicle has seen better days";
                    break;
                case 3:
                    obstacle = "laying on it's top, completely flipped " +
                            "upside down.\n" + 
                            "Exactly how the driver managed this is left to your imagination for now";
                    break;
                case 4:
                    obstacle = "that has run into another vehicle. Both cars are moderately damaged";
                    break;
                default:
                    break;
            }

            //determine the severity of the fire and medical
            int isFire = rnd.Next(1, 5);
            int isMedical = rnd.Next(1, 5);
            switch (isFire)
            {
                case 1:
                    fireCar = $"You see a small ember burning from underneath the vehicle";
                    break;
                case 2:
                    fireCar = "There is some smoke coming from under the hood of the car";
                    break;
                case 3:
                    fireCar = "You can see flames coming from within the car and smoke pours " +
                        "out of the windows";
                    break;
                case 4:
                    fireCar = "The car is fully enveloped in flames";
                    break;
                default:
                    break;
            }

            switch (isMedical)
            {
                case 1:
                    medical = " who are slightly bruised, but otherwise fine from a glance";
                    break;
                case 2:
                    medical = " who have slght lacerations and are bleeding";
                    break;
                case 3:
                    medical = " who have sustained serious injuries " +
                        "and will require immediate medical attention";
                    break;
                case 4:
                    medical = " who are fading in and out of consciousness";
                    break;
                default:
                    break;
            }

            //determine the conditions and entrapment of the victims
            if (Victims)
            {
                entrapped = rnd.Next(100) <= 50 ? true : false;
                if (entrapped == true)
                {
                    victimsCar = $"You can see people still in the car {medical}.\n" +
                        "They are stuck within the crushed metal. You will be unable to treat them until " +
                        "they are freed";
                }
                else
                {
                    victimsCar = $"You can see people still in the car {medical}.\n" +
                        "They are moving freely";
                }
            }
            else
            {
                victimsCar = "You can see that no one is inside.";
            }

            if (Fire == false)
            {
                fireCar = "";
            }

            //output text of the above conditions
            Console.WriteLine("################################################\n" + 
                "You jump out of the truck as Brandon pulls the parking break.\n" +
                $"You see a car {obstacle}.\n{victimsCar}.\n{fireCar}.\n{crowd}" +
                " gathered around the scene.\n\n");
            Console.ReadKey(true);

            //loop to determine successful mitigation of the scene, requires both medical and fire to be false
            while (Victims || Fire)
            {
                Truck.getTools();
                Console.WriteLine("What will you use?\n");
                string userInput = Console.ReadLine();

                switch (userInput)
                {
                    case "1":
                    case "Medical Bag":
                    case "medical bag":
                        if (entrapped)
                        {
                            Console.WriteLine("\nMike: They are stuck, we need to free them first!\n\n");
                            Console.ReadKey(true);
                        }
                        else if (!Victims)
                        {
                            Console.WriteLine("\nMike: There is no one left, you need deal with the other " +
                                "hazards!\n\n");
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nMike: You grab them and I'll bring them to triage. " +
                                "Good job!\n\n");
                            Victims = false;
                            Console.ReadKey(true);
                        }
                        break;
                    case "2":
                    case "Jaws of Life":
                    case "jaws of life":
                        if (entrapped)
                        {
                            Console.WriteLine("Alternate \'F\' and \'J\' to pry to door open...\n\n");
                            for (int i = (RootCause * 3); i > 0;)
                            {
                                if (Console.ReadKey().Key == ConsoleKey.F)
                                {
                                    Console.WriteLine("\b...\n");
                                    i--;

                                    if (Console.ReadKey().Key == ConsoleKey.J)
                                    {
                                        Console.WriteLine("\b...\n");
                                        i--;
                                    }
                                }
                            }
                            entrapped = false;
                            Console.ReadKey(true);
                        }
                        else if (!Victims)
                        {
                            Console.WriteLine("\nMike: There's no one inside! We have other things to " +
                                "worry about!\n\n");
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nMike: We won't have a problem getting to the people " +
                                "inside. Try something different!\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "3":
                    case "Handline":
                    case "handline":
                        if (Fire)
                        {
                            Console.WriteLine("\nMike: Brandon's got the pump on and a line pulled, " +
                                "grab it and hit that fire!\n\n" +
                                "You move into the fight the fire, after a minutes you have it under " +
                                "control and only some steam rises in it's place.\n");
                            Fire = false;
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nMike: What are ya doing, where do you see a fire?!\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "4":
                    case "Resupply Line":
                    case "resupply line":
                        if (Fire)
                        {
                            Console.WriteLine("\nYou go to grab the resupply line, only to see it's already " +
                                "been connected to a hydrandt next to the truck.\n\n");
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nThere won't be a need for that...\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "5":
                    case "Axe":
                    case "axe":
                        Console.WriteLine("\nMike: Alright, calm down, we don't need that...\n\n");
                        Console.ReadKey(true);
                        break;
                    default:
                        Console.WriteLine("\nMike: Grab a real tool and be helpful...\n\n");
                        Console.ReadKey(true);
                        break;
                }
            }
            Console.WriteLine("Tom: Well, there is nothing we can do from here, I'll turn this over " +
                "to the police and we can head back to the station. Good job newbie.\n\n");
            Console.ReadKey(true);
        } 

        //
        //STRUCTURAL
        //
        public void exeCallStruc(Calls x)
        {
            bool resupply = false;
            bool searchPattern = rnd.Next(100) <= 50 ? true : false;
            bool isVictim;

            int rooms = 0;
            string fireStruc = " ";
            string building = " ";
            string search = " ";
            string roomCon = " ";
            string find = " ";
            string fireSize = " ";

            //type of building involved with the fire
            switch (RootCause)
            {
                case 1:
                    building = "a shed in the backyard of a small home";
                    rooms = 1;
                    break;
                case 2:
                    building = "a small one-story cottage at the end of a culdesac";
                    rooms = 3;
                    break;
                case 3:
                    building = "a two-story town house with neighbors close by";
                    rooms = 4;
                    break;
                case 4:
                    building = "a three-story house in the center of a wide street";
                    rooms = 5;
                    break;
                default:
                    break;
            }

            //severity of fire and room conditions
            int isFire = rnd.Next(1, 5);
            switch (isFire)
            {
                case 1:
                    fireStruc = "There is a small plume of smoke coming from the window.";
                    roomCon = "everything is cleary visible";
                    find = "see";
                    fireSize = "a pile of burning embers";
                    break;
                case 2:
                    fireStruc = "You can see a soft orange glow visible from the front window";
                    roomCon = "there is light smoke hovering below the ceiling, but you can see well enough";
                    find = "see";
                    fireSize = "a decently sized but mostly contained fire. However it could grow quickly if left alone";
                    break;
                case 3:
                    fireStruc = "A noticeable pillar of flame has burst through one of the windows";
                    roomCon = "your vision is completely obstructed by smoke past a few feet.";
                    find = "feel";
                    fireSize = "a violent fire stretching to the ceiling";
                    break;
                case 4:
                    fireStruc = "A heavy black pillar of smoke coming form the rear of the structure";
                    roomCon = "the heavy black smoke has filled the builing, you are all but blind";
                    find = "feel";
                    fireSize = "an inferno stretching across the ceiling and spanning the width of the room";
                    break;
                default:
                    break;
            }

            //output text of the above conditions
            Console.WriteLine("################################################\n" +
                "You jump out of the truck as Brandon pulls the parking break.\n" +
                $"You see {building}.\n{fireStruc}.\n{crowd}" +
                " gathered around the scene.\n\n");
            Console.ReadKey(true);

            //establish water source 
            while (!resupply)
            {
                Console.WriteLine("Brandon: We gotta get water to the truck before we can start the attack on " +
                    "the fire!\n");
                Truck.getTools();
                string userInput = Console.ReadLine();

                switch (userInput)
                {
                    case "1":
                    case "Medical Bag":
                    case "medical bag":
                        Console.WriteLine("\nBrandon: No! We need to establish a water source!\n\n");
                        Console.ReadKey(true);
                        break;
                    case "2":
                    case "Jaws of Life":
                    case "jaws of life":
                        Console.WriteLine("\nBrandon: You are kidding right? Maybe you should go back to the " +
                            "academy...\n\n");
                        Console.ReadKey(true);
                        break;
                    case "3":
                    case "Handline":
                    case "handline":
                        Console.WriteLine("\nBrandon: Hey, they'll pull the lines out while you get water to " +
                            "the truck.\n\n");
                        Console.ReadKey(true);
                        break;
                    case "4":
                    case "Resupply Line":
                    case "resupply line":
                        Console.WriteLine("\nYou run the 5\" line out to the hydrant and wait for Brandon to give you " +
                            "the signal to turn it on.");
                        Console.ReadKey(true);
                        Console.WriteLine("\nBrandon gives you a thumbs up. You spin the wrench around the top " +
                            "of the hydrant and water starts running\n" +
                            "through the hose toward the truck.\n\n" +
                            "You run back, where Mike and Tom have pulled the handlines out.\n");
                        resupply = true;
                        Console.ReadKey(true);
                        break;
                    case "5":
                    case "Axe":
                    case "axe":
                        Console.WriteLine("\nBrandon: Dude... what the heck are you doing?\n\n");
                        Console.ReadKey(true);
                        break;
                    default:
                        Console.WriteLine("\nBrandon: Get the resupply line! We don't have time for this...\n\n");
                        Console.ReadKey(true);
                        break;
                }
            }

            //preparing to enter the building
            Console.WriteLine("\nTom: Make sure you grab a tool before you go in.\n\n" + 
                "You grab the Axe with a Haligan and meet Mike at the hose.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Mike: You're up front, I'll back you up on the line. Let's get to the door.\n");
            Console.ReadKey(true);

            //search pattern
            if(searchPattern)
            {
                search = "right";
            }
            else
            {
                search = "left";
            }

            Console.WriteLine("\nMike grabs the line and queues his radio.\n" +
                $"Mike: Command, This is interior, we're going to be making entry doing a {search}-handed " +
                "search pattern.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("You check to door for heat, and pull it open.\n\n");
            Console.ReadKey(true);

            //inside the building
            while(rooms > 0)
            {
                Console.WriteLine($"You enter the room, {roomCon}."); //determines if there are victims in the room
                if(Victims)
                {
                    isVictim = rnd.Next(100) <= 40 ? true : false; //RNG to detrermine if there is a victim in each room
                    if(isVictim)
                    {
                        Console.WriteLine($"You {find} a body lying motionless on the floor.\n" +
                            "You yell for Mike.\n");
                        Console.ReadKey(true);

                        Console.WriteLine("Mike: Alright lets get them out of here!\n\n");
                        Console.ReadKey(true);

                        //for loop to drag the person out
                        Console.WriteLine("Alternate \'F\' and \'J\' to drag the person out...\n\n");
                        for(int i = (RootCause * 4); i > 0;)
                        {
                            if (Console.ReadKey().Key == ConsoleKey.F)
                            {
                                Console.WriteLine("\b...\n");
                                i--;

                                if (Console.ReadKey().Key == ConsoleKey.J)
                                {
                                    Console.WriteLine("\b...\n");
                                    i--;
                                }
                            }
                        }
                        Console.WriteLine("Once you get the person outside and away from the structure; you and Mike " +
                            "head back in, following your handline to get\n" + 
                            "back to where you were.");
                    }
                }

                //put out the fire
                Console.WriteLine($"You see {fireSize}.\n\n" +
                    "Mike: Hit it! Let's get that thing out!\n\n" + 
                    "Press the Spacebar to put out the fire...");
                for(int i = (isFire * 4); i > 0;)
                {
                    if(Console.ReadKey().Key == ConsoleKey.Spacebar)
                    {
                        Console.WriteLine("\b...\n");
                        i--; 
                    }
                }
                rooms--;
                Console.WriteLine("The flames subside, replaced by steam filling the room.\n\n" +
                    "Mike: Good job, let's move!\n");
                Console.ReadKey(true);
            }
            Console.WriteLine("Mike: That's all of it. Let's head back outside\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Tom: I just let dispatch know that we have extinguished the fire, let's reservice and " +
                "head back home.\n\n");
            Console.ReadKey(true);
        }

        //
        // MEDICAL
        //
        public void exeCallsMed(Calls x)
        {
            Random rnd = new Random();

            bool male = rnd.Next(100) <= 50 ? true : false; //determine the sex of the patient
            bool CPR = false;
            bool ambu = false;  //determines if the medics have arrived on scene
            bool testedGlu = false; //checks if the player tested the patients glucose levels

            string patient = " ";
            string patAge = " ";
            string patCon = " ";

            if(male)
            {
                patient = "male";
            }
            else
            {
                patient = "female";
            }

            int i = rnd.Next(1, 5);
            switch(i)
            {
                case 1:
                    patAge = $"a young {patient}, likely still in highschool";
                    break;
                case 2:
                    patAge = $"a young adult {patient}, probably in their 20's or 30's";
                    break;
                case 3:
                    patAge = $"an adult {patient}, likely no older than 50";
                    break;
                case 4:
                    patAge = $"an older {patient}, well into old age";
                    break;
                default:
                    break;
            }

            switch (RootCause)
            {
                case 1:
                    patCon = "they are sitting up right, but look distressed";
                    break;
                case 2:
                    patCon = "they have a broken bone";
                    break;
                case 3:
                    patCon = "that they look to be out of it and are having trouble keeping their head up";
                    break;
                case 4:
                    patCon = "they are unconscious and don't appear to be breathing";
                    CPR = true;
                    break;
                default:
                    break;
            }

            //output the conditons for the call
            Console.WriteLine("################################################\n" +
                "You jump out of the truck as Brandon pulls the parking break.\n" +
                $"You see {patAge}.\nYou can see {patCon}.\n{crowd}" +
                " gathered around the scene.\n\n");
            Console.ReadKey(true);

            Console.WriteLine("Tom: Mike, get their vitals and information if you can. We'll start doing what we can.\n" + 
               "Probie, grab the medical bag!\n\n");

            while(!ambu)
            {
                Truck.medBag();
                Console.WriteLine("What will you use?\n\n");
                string userInput = Console.ReadLine();

                if(RootCause != 4)
                {
                    CPR = rnd.Next(100) <= 20 ? true : false;
                    if(CPR)
                    {
                        Console.WriteLine("\n################################################\n" + 
                            "You notice the patient suddenly slump wiht no signs of consciousness\n\n");
                        RootCause = 4;
                    }
                }

                switch(userInput)
                {
                    case "1":
                    case "O2 Bottle with Mask":
                    case "o2 bottle with mask":
                    case "O2 Bottle":
                    case "o2 bottle":
                    case "O2":
                    case "o2":
                        if(RootCause == 1)
                        {
                            Console.WriteLine("\nTom: They look a little woozy, let's get them some oxygen and have " + 
                                "the ambulance transport them.\n\nYou place the mask around their face and watch " +
                                "them perk up a bit. After some time they start to feel better and do not wish " + 
                                "for any further care.\n\n");
                            ambu = true;
                            Console.ReadKey(true);
                        }
                        else if(RootCause == 4 || CPR)
                        {
                            Console.WriteLine("\nTom: Brandon can grab that while we start CPR, c'mon!\n\n");
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nTom: We won't need that...\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "2":
                    case "Bone Splint":
                    case "bone splint":
                        if (RootCause == 2)
                        {
                            Console.WriteLine("\nTom: They have a pretty nasty looking break. Good job, let's " +
                                "get that break secured and get them on an ambulance.\n\nYou apply the splint " +
                                "and get them as comfortable as possible. The ambulance arrives shortly and you " +
                                " turn them over to\n" + 
                                "the medics.\n\n");
                            ambu = true;
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nTom: That won't be helpful for them at all.\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "3":
                    case "Glucometer":
                    case "glucometer":
                        if(RootCause == 3)
                        {
                            Console.WriteLine("\nTom: Good eye, they could be diabetic.\n\nYou test their blood " +
                                "and see that their blood sugar is low.\n\n");
                            testedGlu = true;
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nTom: That isn't what we need right now...\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "4":
                    case "Glucose Gel":
                    case "glucose gel":
                        if(testedGlu)
                        {
                            Console.WriteLine("After ensuring they are able to swallow, you squeeze some of the gel " +
                                "into their mouth. After some time they start to\n" + 
                                "perk up. After a while they swear they'll be fine on their own without " + 
                                "further care.\n\n");
                            ambu = true;
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("\nTom: I don't know if that's what we need right now...\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    case "5":
                    case "AED & begin CPR":
                    case "aed & begin cpr":
                    case "AED and begin CPR":
                    case "aed and begin cpr":
                    case "AED":
                    case "aed":
                    case "CPR":
                    case "cpr":
                        if (RootCause == 4 || CPR)
                        {
                            Console.WriteLine("\nTom: We have to act quick! Start compressions, I'll set the AED up.\n\n");
                            for (int u = 2; u > 0; u--)
                            {
                                Console.WriteLine("Alternate \'F\' and \'J\' to do compressions...\n\n");
                                for (int j = 16; j > 0;)
                                {
                                    if (Console.ReadKey().Key == ConsoleKey.F)
                                    {
                                        Console.WriteLine("\b...\n");
                                        j--;

                                        if (Console.ReadKey().Key == ConsoleKey.J)
                                        {
                                            Console.WriteLine("\b...\n");
                                            j--;
                                        }
                                    }
                                }
                                Console.WriteLine("Press Space bar twice to breath for the patient...\n\n");
                                for (int k = 2; k > 0;)
                                    if (Console.ReadKey().Key == ConsoleKey.Spacebar)
                                    {
                                        k--;
                                    }
                            }
                            Console.WriteLine("\nYou continue with CPR till the ambulance arrives. You keep working " +
                                "the patient in the back of the ambulance on the\n" +
                                "way to the hospital till they are taken to the ER.\n\n");
                            ambu = true;
                            Console.ReadKey(true);
                        }
                        else
                        {
                            Console.WriteLine("Tom: You're only going to make them mad if you use that!\n\n");
                            Console.ReadKey(true);
                        }
                        break;
                    default:
                        break;
                }

            }
            Console.WriteLine("\nWe can terminate. Let's head home.\n\n");
            Console.ReadKey(true);
        }
    }
}

