﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public class Truck
    {
        //fields
        public string Tools;

        //constructor
        public Truck(string tools)
        {
            this.Tools = tools;
        }

        //methods
        //prints a list of tools for use during the calls
        public static void getTools()
        {
            Console.WriteLine("Tools: \n" + " 1. Medical Bag  2. Jaws of Life  3. Handline  " + 
                "4. Resupply Line  5. Axe  \n\n");
        }

        //prints a list of tools in the medical bag for use during medical calls only
        public static void medBag()

        {
            Console.WriteLine("Medical Bag:  \n" + "1. O2 Bottle with Mask  2. Bone Splint  3. Glucometer  " + 
                "4. Glucose Gel  5.  AED & begin CPR\n\n");
        }
    }
}
